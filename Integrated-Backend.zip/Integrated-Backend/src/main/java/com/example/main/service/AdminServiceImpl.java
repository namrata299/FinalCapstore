package com.example.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.main.controller.AdminController;
import com.example.main.dao.AdminDao;
import com.example.main.email_token.ConfirmationToken;
import com.example.main.email_token.EmailSenderService;
import com.example.main.exception.UserAlreadyExistsException;
import com.example.main.model.CommonFeedback;
import com.example.main.model.Coupon;
import com.example.main.model.CustomerDetails;
import com.example.main.model.MerchantDetails;
import com.example.main.model.Product;
import com.example.main.model.ProductFeedback;
import com.example.main.repository.ConfirmationTokenRepository;
import com.example.main.repository.CouponRepository;
import com.example.main.repository.MerchantRepository;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{

	
	org.slf4j.Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);	
	@Autowired
	private AdminDao adminDao;
	
	@Autowired
	ConfirmationTokenRepository confirmationTokenRepository;
	
	@Autowired
	MerchantRepository merchantRepository;
	
	@Autowired
	CouponRepository couponRepo;
	
	@Autowired
	EmailSenderService emailSenderService;

	//Merchant: 
	@Override
	public void addMerchant(MerchantDetails m) throws MessagingException, UserAlreadyExistsException {
		logger.trace("Add Merchant working...");
		 adminDao.addMerchant(m);
		
	}

	@Override
	public void removeMerchantById(int merchantId) {
		logger.trace("removeMerchantById working...");
		adminDao.removeMerchantById(merchantId);
	}
	

	@Override
	public List<MerchantDetails> getAllMerchant() {
		logger.trace("getAllMerchant working...");
		List<MerchantDetails> merchants=new ArrayList<MerchantDetails>();
		adminDao.findAllMerchants().forEach(merchants::add);
		return merchants;
	}

	@Override
	public boolean updateMerchant(MerchantDetails updatedMerchant) {
		logger.trace("updateMerchant working...");
		return adminDao.updateMerchant(updatedMerchant);
	}

	@Override
	public MerchantDetails findMerchantById(int userId) {
		logger.trace("findMerchantById working...");
		return adminDao.findMerchantById(userId);
	}
	
    
	
	public MerchantDetails verifyMerchantDetails(String email) {
		logger.trace("verifyMerchantDetails working...");
		return adminDao.findMerchantByeMail(email);
	}


	public MerchantDetails getApproval(String email, boolean approved) throws MessagingException, UserAlreadyExistsException {
		logger.trace("getApproval Merchant working...");
		MerchantDetails merchant = adminDao.findMerchantByeMail(email);
		merchant.setApproved(approved);
		adminDao.addMerchant(merchant);
		return merchant;
	}
	
	
	public List<MerchantDetails> getMerchants() {
		logger.trace("getMerchants  working...");
		List<MerchantDetails> merchant = new ArrayList<>();
		adminDao.findAllMerchants().forEach(merchant::add);
		return merchant;
	}


	public boolean confirmAccount(String confirmationToken) {
		boolean val=adminDao.confirmAccount(confirmationToken);
		return val;
	}
	
	public MerchantDetails generateToken(String confirmationToken, String action) throws MessagingException{
		MerchantDetails merchant=adminDao.generateToken(confirmationToken, action);
		return merchant;
	}

	public MerchantDetails userLogin(String confToken) {
		return adminDao.userLogin(confToken);
	}
	

	
	//Product:
	@Override
	public Product addProduct(Product product) {
		logger.trace("addProduct  working...");
		return adminDao.addProduct(product);
	}

	@Override
	public boolean removeProduct(int productId) {
		logger.trace("removeProduct working...");
		return adminDao.removeProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		logger.trace("getAllProducts working...");
		return adminDao.getAllProducts();
	}

	@Override
	public Product getProductByProductId(int productId) {
		logger.trace("getProductByProductId working...");
		return adminDao.getProductByProductId(productId);
	}

	@Override
	public boolean update(Product product) {
		logger.trace("update Product  working...");
		return adminDao.update(product);
	}

	@Override
	public boolean updateCategoryByCategory(String productCategory, String updatedCategory) {
		logger.trace("updateCategoryByCategory working...");
		return adminDao.updateCategoryByCategory(productCategory, updatedCategory);
	}
	
	
	//Customer:

	@Override
	public void removeCustomerById(int userId) {
		logger.trace("removeCustomerById working...");
		adminDao.removeCustomerById(userId);
	}


	@Override
	public CustomerDetails findCustomerById(int userId) {
		logger.trace("findCustomerById working...");
		return adminDao.findCustomerById(userId);
	}

	@Override
	public CustomerDetails findCustomerByName(String name) {
		logger.trace("findCustomerByName working...");
		return adminDao.findCustomerByName(name);
	}

	@Override
	public List<CustomerDetails> getAllCustomers() {
		logger.trace("get All Customers working...");
		return adminDao.getAllCustomers();
	}

	
	
	
	
	//CommonFeedback:
	
	
	@Override
	public List<CommonFeedback> getAllCommonFeedbackByUserId(int userId) {
		logger.trace(" getAllCommonFeedbackByUserId working...");
		return adminDao.getAllCommonFeedbackByUserId(userId);
	}

	@Override
	public CommonFeedback getCommonFeedbackById(int feedbackId) {
		logger.trace("getCommonFeedbackById working...");
		return adminDao.getCommonFeedbackById(feedbackId);
	}
	
	@Override
	public List<CommonFeedback> getAllCommonFeedbackByProductId(int productId) {
		logger.trace("getAll CommonFeedback By ProductId working...");
		return adminDao.getAllCommonFeedbackByProductId(productId);
	}

	@Override
	public int forwardRequestToMerchant(int feedbackId) {
		logger.trace("forward Request To Merchantworking...");
		return adminDao.forwardRequestToMerchant(feedbackId);
	}

	@Override
	public String forwardResponseToCustomer(int feedbackId) {
		logger.trace("forward Response To Customer working...");
		return adminDao.forwardResponseToCustomer(feedbackId);
	}
	
	@Override
	public List<CommonFeedback> getAll() {
		logger.trace("getAll CommonFeedback working...");
		return adminDao.getAll();
	}


	
	
	
	
	//ProductFeedback:
	

	@Override
	public void removeProductFeedbackkById(int feedbackId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeProductFeedbackByUserId(int userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductFeedback> getAllProductFeedbackByUserId(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductFeedback getProductFeedbackById(int feedbackId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductFeedback> getProductFeedbackByProductId(int productId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public ProductFeedback addCommonFeedback(ProductFeedback pfd) {
		// TODO Auto-generated method stub
		return null;
	}
	

	

	//Coupon:
	

		@Override
		public List<Coupon> getAllCoupons() {
			//List<Coupon> coupon = new ArrayList<>();
			//couponRepo.findAll().forEach(coupon::add);
			List<Coupon> coupon = adminDao.getAllCoupons();
			return coupon;
		}

		@Override
		public Coupon getCouponById(int couponId) throws Exception {
			Coupon coupon = adminDao.getCouponById(couponId);
			return coupon;
		}

		@Override
		public Coupon getCouponByCode(String couponCode) {
			Coupon coupon = adminDao.getCouponByCode(couponCode);
			return coupon;
		}

		@Override
		public void addCoupon(@Valid Coupon coupon) throws MessagingException {

			adminDao.addCoupon(coupon);
		}

		@Override
		public Coupon generateCoupon(int couponId, int id) throws Exception {

			Coupon coupon = adminDao.generateCoupon(couponId, id);
			return coupon;
		}

		@Override
		public Coupon sendCoupon(int couponId) throws Exception {

			Coupon coupon = adminDao.sendCoupon(couponId);
	        return coupon;
		}

		@Override
		public Boolean deleteCoupon(int couponId) {

			boolean exists = adminDao.deleteCoupon(couponId);
			return true;
		}

		

	

	

}
