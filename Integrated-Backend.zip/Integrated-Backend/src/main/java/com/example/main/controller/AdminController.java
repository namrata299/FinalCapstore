package com.example.main.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.main.email_token.ConfirmationToken;
import com.example.main.email_token.EmailSenderService;
import com.example.main.exception.EmptyRepositoryException;
import com.example.main.exception.UserAlreadyExistsException;
import com.example.main.exception.ValidAmountException;
import com.example.main.model.CommonFeedback;
import com.example.main.model.Coupon;
import com.example.main.model.CustomerDetails;
import com.example.main.model.MerchantDetails;
import com.example.main.model.Product;
import com.example.main.model.User;
import com.example.main.repository.ConfirmationTokenRepository;
import com.example.main.repository.CouponRepository;
import com.example.main.repository.MerchantRepository;
import com.example.main.repository.ProductRepository;
import com.example.main.repository.UserRepository;
import com.example.main.service.AdminService;
import com.example.main.service.EmailService;

@CrossOrigin(origins ="http://localhost:4200")
@RestController("AdminController")
@RequestMapping(value="/capstore/admin",method= {RequestMethod.POST, RequestMethod.GET, RequestMethod.PUT})
public class AdminController {

	org.slf4j.Logger logger = LoggerFactory.getLogger(AdminController.class);		
			
		@Autowired
		private AdminService adminService;
		
		@Autowired
		private EmailService emailService;
		
		@Autowired
		private ProductRepository productRepository;
		
		
		@Autowired
		UserRepository userRepository;
		
		@Autowired 
		MerchantRepository merchantRepository;
		
		@Autowired
		CouponRepository couponRepo;
		
		@Autowired
		ConfirmationTokenRepository confirmationTokenRepository;
		
		@Autowired
		EmailSenderService emailSenderService;
		
		
		//Customer:
		
		@GetMapping("/getAllCustomers")
		public ResponseEntity<List<CustomerDetails>> getAllCustomers() throws EmptyRepositoryException
		   {
			logger.trace("Get all customers working...");
				List<CustomerDetails> customers= adminService.getAllCustomers();
				System.out.println("In Get All Customers");
				System.out.println(customers);
				if(customers.isEmpty()) {
					throw new EmptyRepositoryException("No Customers in the Repository");
				}
				
				return new ResponseEntity<List<CustomerDetails>>(customers, HttpStatus.OK);
			}
		  
		@DeleteMapping("/deleteCustomer/{userId}")
		public  String deleteCustomer(@PathVariable("userId")int userId) {
			logger.trace("Delete Customer working...");
			
			 adminService.removeCustomerById(userId);
			 return "Account removed successfully!";
			}
		 
		 
		 
		 
		 
		 //merchant:
		 
		@RequestMapping(value="/registerMerchant", method = RequestMethod.POST)
	    public ResponseEntity<?> registerMerchant(@Valid @RequestBody MerchantDetails md) throws MessagingException, UserAlreadyExistsException
	    {
			logger.trace("Register Merchant working...");
	       
	        adminService.addMerchant(md);
            return ResponseEntity.ok(HttpStatus.OK);
	    }
	    
	    
	    @RequestMapping(value="/confirm-account", method= {RequestMethod.GET, RequestMethod.POST})
	    public ResponseEntity<?> confirmUserAccount(@Valid  @RequestParam("token") String confirmationToken)
	    {
	    	logger.trace("confirm  Customer working...");
	      

	    	boolean val = adminService.confirmAccount(confirmationToken);
	        if(val == true) {
	        	return ResponseEntity.ok(HttpStatus.OK);
	        }
	        else {
	        	return new ResponseEntity<Error>(HttpStatus.CONFLICT);
	        }
	     }
	    
	    @GetMapping("/generateToken")
	    public ResponseEntity<?> generateToken(@Valid  @RequestParam("token") String confirmationToken,@Valid  @RequestParam("action") String action) throws MessagingException{
	    	
	    	logger.trace("Generate  token working...");
	    	MerchantDetails merchant = adminService.generateToken(confirmationToken, action);
	        return ResponseEntity.ok().body(merchant);
	    }
	    
	    @RequestMapping(value="/login", method= {RequestMethod.GET, RequestMethod.POST})
	    public ResponseEntity<?> userLogin(@Valid @RequestBody String[] userCredentials) {
	    	logger.trace("Login  working...");
	    	String email=userCredentials[0];
	    	String pass=userCredentials[1];
	    	String role=userCredentials[2];
	    	System.out.println(email+pass+role);
	    	if (role.equals("Customer")) {
	    		CustomerDetails cd=userRepository.findCustomerByEmailIgnoreCase(email);
	    		if(cd!=null && cd.isActive()==true) {
	    			if(pass.equals(cd.getPassword())) {
	    				return ResponseEntity.ok().body(cd);
	    			}
	    		}
	    	}
	    	else {
	    		MerchantDetails md=userRepository.findMerchantByEmailIgnoreCase(email);
	    		if(md!=null && md.isActive()==true) {
	    			if(pass.equals(md.getPassword())) {
	    				return ResponseEntity.ok().body(md);
	    			}
	    		}
	    	}
	    	return new ResponseEntity<Error>(HttpStatus.CONFLICT);
	    }
	    
	    @RequestMapping(value="/getMerchant", method= {RequestMethod.GET, RequestMethod.POST})
	    public ResponseEntity<?> userLogin(@Valid  @RequestParam("token") String confToken) {
	    	logger.trace("Get Merchant  working...");
	    	ConfirmationToken token = confirmationTokenRepository.findByConfirmationToken(confToken);
	    	MerchantDetails md=userRepository.findMerchantById(token.getUid());
	    	return ResponseEntity.ok().body(md);
	    }
		
		 

		@GetMapping(value = "/findMerchantById/{userId}")
		public MerchantDetails getMerchant(@PathVariable("userId")Integer userId) {
			logger.trace("Find MerchantbyID  working...");
			return adminService.findMerchantById(userId);
			
		}
		
		
		 @GetMapping("/getAllMerchants")
		 public ResponseEntity<List<MerchantDetails>> getAllMerchants(){
			 logger.trace("Get All  Merchants working...");
			List<MerchantDetails> merchants= adminService.getAllMerchant();
				if(merchants.isEmpty()) {
				return new ResponseEntity("Sorry! No Merchant Found!", HttpStatus.NOT_FOUND);
			}
					
				return new ResponseEntity<List<MerchantDetails>>(merchants, HttpStatus.OK);		
			}
		 
		@DeleteMapping("/deleteMerchant/{merchantId}")
		public  ResponseEntity<Boolean> deleteMerchant(@PathVariable("merchantId")int merchantId) {
			logger.trace("Delete Merchant working...");
			 adminService.removeMerchantById(merchantId);
			
			
			 return  ResponseEntity.ok().body(true);
			}
		
		
		@RequestMapping(value ="/inviteUsers",method = { RequestMethod.GET,RequestMethod.POST })
		public void invite(User user){
			logger.trace("Invite  User working...");
		     emailService.sendInvitationsToUsers(user);	
		}
		
		@PutMapping(value="/updateMerchant")
		public boolean update(@RequestBody MerchantDetails merchant) {
			logger.trace("Update Merchant working...");
		     return adminService.updateMerchant(merchant);
		}
		
		//Product: 
		
		 @DeleteMapping("deleteProduct/{productID}")
		 public boolean DeleteProduct(@PathVariable("productID")int productID)
		 {
			 logger.trace("Delete Product working...");
			 return adminService.removeProduct(productID);
		 }
		
		@PostMapping("/addProduct")
		public Product addProduct(@RequestBody Product product) throws ValidAmountException {
			logger.trace("add Product working...");
			product.setProductId((int)(Math.random()*100000));
			double price=product.getProductPrice();
			if(price<0)
			{
				throw new ValidAmountException("Please Enter valid amount");
			}
			product.setDiscount(0);
			return adminService.addProduct(product);
		}
		
		@GetMapping("/getAllProducts")
		public List<Product> getAllProducts() throws EmptyRepositoryException{
			logger.trace("Get all  Products working...");
			List<Product> products= adminService.getAllProducts();
			
			if(products==null)
			{
				throw new EmptyRepositoryException("No Products Found");
			}
			return products;
		}
		
		@GetMapping("/getProductById/{productId}")
		Product getProductByProductId(@PathVariable int productId) {
			logger.trace("Get Product by iD  working...");
			return adminService.getProductByProductId(productId);
		}
		
		@PutMapping("/updateProduct")
		public boolean update(@RequestBody Product product) throws ValidAmountException {
			logger.trace("Update working...");
			double price=product.getProductPrice();
			
			if(price<0)
			{
				throw new ValidAmountException("Please Enter Valid amount");
			}
			return adminService.update(product);
		}
		
		@PutMapping("/updateCategoryByCategory")
		boolean updateCategoryByCategory(@RequestParam("productCategory")String productCategory, @RequestParam("updatedCategory")String updatedCategory) {
			logger.trace("Update Category working...");
			return adminService.updateCategoryByCategory(productCategory, updatedCategory);
		}
			
	
		//Coupon
		
		
		@PostMapping(value = "/create")
		public ResponseEntity<Coupon> addCoupon(@Valid @RequestBody Coupon coupon) throws MessagingException, ValidAmountException {
			logger.trace("Add Coupon  working...");

			int amount=coupon.getCouponAmount();
			if(amount<0)
			{
				throw new ValidAmountException("Please Enter Valid amount");
			}
			adminService.addCoupon(coupon);
	            
				return new ResponseEntity<Coupon>(HttpStatus.CREATED);
		}
	    
	    @PutMapping("/generateCoupon/{couponId}/{id}")
	    public Coupon generateCoupon(@PathVariable("couponId") int couponId, @PathVariable("id") int id) throws Exception{
	    	logger.trace("Generate  Coupon working...");
    
	        return adminService.generateCoupon(couponId, id);
	    }
	  
	    ///////////////////////////////new/////////////////////////////////
	    @PutMapping("/sendCoupon/{couponId}")
	    public Coupon sendCoupon(@PathVariable("couponId") int couponId) throws Exception{
	    	
	    	logger.trace("Send Coupon  working...");
	        return adminService.sendCoupon(couponId);
	    }
	    
	    ////////////////////////////////////////////////////////////////////////
	  	@GetMapping("/coupons")
		public ResponseEntity<List<Coupon>>getAllCoupons(){
//	  		List<Coupon> coupon = new ArrayList<>();
//			couponRepo.findAll().forEach(coupon::add);
	  		logger.trace("Get ALl coupons  working...");
			return new ResponseEntity<List<Coupon>>(adminService.getAllCoupons(),HttpStatus.OK);
		}
		
		@PutMapping("/Id/{couponId}")
		public ResponseEntity<Coupon> getCouponById(@PathVariable("couponId") int couponId) throws Exception{
			logger.trace("Get Coupon by Id  working...");

			return new ResponseEntity<Coupon>(adminService.getCouponById(couponId), HttpStatus.OK);
		}
		
		@PutMapping("/Code/{couponCode}")
		public ResponseEntity<Coupon> getCoupon(@PathVariable("couponCode") String couponCode){
			Coupon coupon = adminService.getCouponByCode(couponCode);
			logger.trace("Get coupon working...");
			if(coupon==null) {
				return new ResponseEntity("Sorry! Coupon not found!",HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<Coupon>(coupon, HttpStatus.OK);
		}
		
		@DeleteMapping("/coupon/{promocodeId}")
		public ResponseEntity<Boolean> deleteCoupon(@PathVariable("promocodeId") int couponId){
			logger.trace("Delete coupons  working...");
			//System.out.println("Deleted1");
			adminService.deleteCoupon(couponId);
			System.out.println("Deleted2");
			return ResponseEntity.ok().body(true);
			
		}
		
		
		
	//
	@PutMapping("/addDiscount/{discount}/{productID}")
		public ResponseEntity<Boolean> addDiscount(@PathVariable("discount") int discount,@PathVariable("productID") int productID)
		{
			logger.trace("Add Discount Customer working...");
			Product product=productRepository.findById(productID).get();
			product.setDiscount(discount);
			productRepository.save(product);
			return ResponseEntity.ok().body(true);
			
		}
	
	
	//Common Feedback:
		
     	@PutMapping(value="/forwardRequestToMerchant/{feedbackId}")
		public int forwardRequestToMerchant(@PathVariable int feedbackId) {
     		logger.trace("forwardRequestToMerchant  working...");
			return adminService.forwardRequestToMerchant(feedbackId);
		}
		
		@GetMapping(value="/forwardResponseToCustomer/{feedbackId}")
		public String forwardResponseToCustomer(@PathVariable int feedbackId) {
			logger.trace("forward Response To Customer  working...");
			return adminService.forwardResponseToCustomer(feedbackId);
		}
		
		@GetMapping(value="/getAllCommonFeedbackByUserId/{userId}")
		public List<CommonFeedback> getAllCommonFeedbackByUserId(@PathVariable("userId") int userId) {
			logger.trace("get AllCommonFeedbackByUserId  working...");
			return adminService.getAllCommonFeedbackByUserId(userId);
		}
		
		@GetMapping(value="/getCommonFeedbackById/{feedbackId}")
		public CommonFeedback getCommonFeedbackById(@PathVariable("feedbackId") int feedbackId) {
			logger.trace("get CommonFeedback By Id  working...");
			return adminService.getCommonFeedbackById(feedbackId);
		}
		
		@GetMapping(value="/getAllCommonFeedbackByProductId/{productId}")
		public List<CommonFeedback> getAllCommonFeedbackByProductId(@PathVariable("productId") int productId) {
			logger.trace("getAllCommonFeedbackBy Product Id  working...");
			return adminService.getAllCommonFeedbackByProductId(productId);
		}
		
		@GetMapping(value="/getAllCommonFeedback")
		public List<CommonFeedback> getAll() {
			logger.trace("getAll CommonFeedback  working...");
			return adminService.getAll();
		}

		public Object getAllAccounts() {
			// TODO Auto-generated method stub
			return null;
		}
		
		 
	}