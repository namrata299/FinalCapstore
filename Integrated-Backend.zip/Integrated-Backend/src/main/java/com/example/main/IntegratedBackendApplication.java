package com.example.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.main.model.CustomerDetails;
import com.example.main.repository.CustomerRepository;

@SpringBootApplication
public class IntegratedBackendApplication implements CommandLineRunner {

	@Autowired
	private CustomerRepository customerRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(IntegratedBackendApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		CustomerDetails customer1 = new CustomerDetails(101,"Customer1", "customer1", "customer1", "customer1@gmail.com", "Customer", true, "Favourite Football team?", "Bayern", "9873426712", null, null, null, null, null, null, null, null);
		CustomerDetails customer2 = new CustomerDetails(102,"Customer2", "customer2", "customer2", "customer2@gmail.com", "Customer", true, "Favourite Football team?", "Bayern", "9872426212", null, null, null, null, null, null, null, null);
		
		customerRepository.save(customer1);
		customerRepository.save(customer2);
	}

}
